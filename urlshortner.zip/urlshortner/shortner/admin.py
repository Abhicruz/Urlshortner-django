from django.contrib import admin
from.models import url

# Register your models here.
admin.site.register(url)
